<h2>BONOBO REFERENCE CHECK ON CLIENT SITE (http://www.bonoboplanet.com/e_commerce/recherche.cfm)</h2>
<br/>
<form action="get-redirected-urls.php" method="post">
<table>
<tr><td valign="top">Enter references (one refernce per line) : </td><td><textarea cols="50" rows="20" name="ids" style="border-radius:10px"></textarea></td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="submit" /></td></tr>
</table>
<br/>
<br/>
<span style="color:red">Note : It will take some time to process ! So pls wait !</span>
</form>
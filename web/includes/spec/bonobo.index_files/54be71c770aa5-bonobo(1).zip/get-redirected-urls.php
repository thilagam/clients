<?php
ini_set('max_execution_time', 300000);
$br = nl2br($_POST['ids'],true);
$urls = explode("<br />", $br);
array_pop($urls);
$urls=array_map('trim',$urls);
echo "<table border=1>";
foreach($urls as $k=>$v)
{
	echo abc("http://www.bonoboplanet.com/e_commerce/recherche.cfm?libelle=".$v,$v);
}
echo "</table>";

function abc($url,$v)
{
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; Linux x86_64; rv:21.0) Gecko/20100101 Firefox/21.0"); // Necessary. The server checks for a valid User-Agent.
curl_exec($ch);

$response = curl_exec($ch);
preg_match_all('/^Location:(.*)$/mi', $response, $matches);
curl_close($ch);
return "<tr><td>".$v."</td><td>".str_replace("Location: ","",@$matches[0][0])."</td></tr>";
}

?>